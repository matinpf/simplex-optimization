﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;





namespace WpfApplication15
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

       

        public MainWindow()
        {
            InitializeComponent();





        }



        private void button_Click(object sender, RoutedEventArgs e)
        {
            string l1;


            //l1 = "1x1+3x2+2x3";
            //listBox.Items.Add(l1);
            //string l2 = "1x1+1x2+1x3<=100";
            //listBox.Items.Add(l2);
            //string l3 = "2x1+1x2+1x3<=120";
            //listBox.Items.Add(l3);
            //300

            //l1 = "20x1+15x2";
            //listBox.Items.Add(l1);
            //string l2 = "1x1+1x2>=20";
            //listBox.Items.Add(l2);
            //string l3 = "2x1+1x2>=30";
            //listBox.Items.Add(l3);
            //string l4 = "1x1+2x2>=50";
            //listBox.Items.Add(l4);
            //2500/6 -min


            //l1 = "20x1+15x2+25x3";
            //listBox.Items.Add(l1);
            //string l2 = "1x1+2x2+1x3<=200";
            //listBox.Items.Add(l2);
            //string l3 = "1x1+2x2+0x3>=50";
            //listBox.Items.Add(l3);
            //string l4 = "2x1+2x2+1x3=100";
            //listBox.Items.Add(l4);
            //750-min


            //l1 = "4x1+3x2+6x3";
            //listBox.Items.Add(l1);
            //string l2 = "3x1+1x2+3x3<=30";
            //listBox.Items.Add(l2);
            //string l3 = "2x1+2x2+3x3<=40";
            //listBox.Items.Add(l3);
            //70 -max



            //l1 = "12x1+8x2";
            //listBox.Items.Add(l1);
            //string l2 = "5x1+2x2<=150";
            //listBox.Items.Add(l2);
            //string l3 = "2x1+3x2<=100";
            //listBox.Items.Add(l3);
            //string l4 = "4x1+2x21<=80";
            //listBox.Items.Add(l4);
            //300 max


            string kind = "min";
            string lmin,op,op2="";
            int fs = 0;

            op2= listBox.Items[0].ToString();


            if (kind.CompareTo(comboBox.Text) == 0) {
                op2 = "";
              lmin = listBox.Items[0].ToString();
                var stringArray5 = lmin.Split('+');
               
                foreach (string s in stringArray5)
                {
                    op = s.Substring(0, 1);
                    if (op.CompareTo("-") != 0)
                    {
                        string aaa = s;
                        op2 = op2 + s.Insert(0, "-") + "+";

                    }
                    else
                    {

                        op2 = op2 + s.Substring(1, s.Length-1) + "+";

                    }

                    fs++;
                }

                op2 = op2.Substring(0, op2.Length - 1);
         
            }


            int tl = listBox.Items.Count;
            int pn = tl - 1;

            string l5 = op2;
             l1 = op2;
            double[,] m = new double[pn, 1];
            int com = 0;

            bool ism = false;

            for (int i = 0; i < pn; i++)
            {

                string l6 = listBox.Items[i + 1].ToString();

                if (l6.Contains("<="))
                {
                    m[i, 0] = 0;
                }
                else if (l6.Contains(">="))
                {
                    ism = true;
                    m[i, 0] = 1;
                    com++;
                }
                else if (l6.Contains("=")) {
                    ism = true;
                    m[i, 0] = 2;
                }
            }




            int k9 = 1;
            var stringArray = l1.Split('+');

            string[,] xb = new string[pn, 1];

            for (int k8 = 0; k8 <pn; k8++) {

                if (m[k8, 0] == 0)
                {

                        xb[k8, 0] = "s" + k9.ToString();
                       
                    
                }
                else {
               
                    xb[k8, 0] = "a" + k9.ToString();
                    
               
                    
                }
                k9++;
            }

            double[,] bp = new double[pn, pn];
            for (int i = 0; i < pn; i++)
            {
                for (int j = 0; j < pn; j++)
                {
                    if (i == j)
                        bp[i, j] = 1;
                    else
                        bp[i, j] = 0;
                }
            }
                   

            double[,] b1 = new double[pn, pn];
            for (int i = 0; i < pn; i++)
            {
                for (int j = 0; j < pn; j++)
                {
                    if (i == j)
                        b1[i, j] = 1;
                    else
                        b1[i, j] = 0;
                }
            }

            double[,] e1 = new double[pn, pn];
            for (int i = 0; i < pn; i++)
            {
                for (int j = 0; j < pn; j++)
                {
                    if (i == j)
                        e1[i, j] = 1;
                    else
                        e1[i, j] = 0;
                }
            }




            string[,] xn = new string[1, stringArray.Length+com];
            k9 = 1;
            for (int k = 0; k < stringArray.Length; k++)
            {
                xn[0, k] = "x"+k9.ToString();
                k9++;
            }

            int jj = 0;
            k9 = 1;
            for (int k8 = 0; k8 < pn; k8++)
            {

                if (m[k8, 0] == 1)
                {
                    xn[0, stringArray.Length + jj] = "s" + k9.ToString();
                    jj++;
                }
                k9++;
            }



            double[,] n = new double[pn, stringArray.Length + com];
            int sd = 0;
            k9 = 0;
            for (int i = 0; i < pn; i++)
            {
                
               var stringArray2 = listBox.Items[i + 1].ToString().Split('+');

                for (int j = 0; j < stringArray.Length + com; j++)
                {

                    if(j>= stringArray.Length)
                    {


                        for (int k8 = sd; k8 < pn; k8++)
                        {
                            sd++;
                            k9++;
                            if (m[k8, 0] == 1)
                            {
                                if (k8 == i )
                                {
                                        n[i, j] = -1;
                                
                                }
                                else { 
                                n[i, j] = 0;

                                }
                                break;

                            }
                            
                        }


                    }
                    else { 
                    string a9 = stringArray2[j].ToString();
                    var stringArray3=a9.Split('x');
                    
                    n[i, j] =Convert.ToDouble( stringArray3[0]) ;

                    }
                }

               sd = 0;
                k9 = 0;
            }




            double[,] cn = new double[1, stringArray.Length+com];
           for(int k=0;k< stringArray.Length; k++)
            {
                double ll;
                var stringArray4=stringArray[k].Split('x');
                cn[0,k] = Convert.ToDouble(stringArray4[0]);
            }
            for (int k = stringArray.Length; k < stringArray.Length + com; k++)
            {

                cn[0, k] = 0;
            }





                double[,] cb = new double[1, pn];

            for (int k = 0; k < pn; k++)
            {
                if(m[k, 0] != 0)
                    cb[0, k] = -100000;
                else
                cb[0, k] = 0;
            }

            double[,] b = new double[pn, 1];
            for (int i = 0; i < pn; i++)
            {
            
                var stringArray5 = listBox.Items[i + 1].ToString().Split('=');
          
                    b[i, 0] = Convert.ToDouble(stringArray5[1]);

            }


            int dor = 0;
            while (true)
            {
                dor++;

                double[,] vorode = new double[1, stringArray.Length];
                //    h = MultiplyMatrix(x, y);

                int cs, sh = 0;

                vorode = MultiplyMatrix(cb, bp);
                vorode = MultiplyMatrix(vorode, n);
                vorode = Multiplydif(vorode, cn);

                int test = 0;

                for (int k = 0; k < stringArray.Length+com; k++)
                {
                    if (vorode[0, k] >= 0)
                        sh++;
                }
                if (sh == vorode.Length || dor == 100)
                    break;



                int rA = vorode.GetLength(0);
                int cA = vorode.GetLength(1);
                double[,] javab = new double[1, 2];
                int min = 0;
                double min2 = vorode[0, 0];
                for (int i = 0; i < rA; i++)
                    for (int j = 0; j < cA; j++)
                    {
                        if (min2 > vorode[i, j])
                        {
                            min = j;
                            min2 = vorode[i, j];
                        }
                    }

                int a1 = min;


                double[,] stonj = new double[pn, 1];
                double[,] stonv = new double[pn, 1];
                double[,] stonx = new double[pn, 1];
                stonj = MultiplyMatrix(bp, b);



                cA = n.GetLength(0);
                double[,] stonv2 = new double[cA, 1];
                int j2 = min;
                for (int i = 0; i < cA; i++)
                {
                    stonv2[i, 0] = n[i, j2];

                }

                //stonj = MultiplyMatrix(bp, b);
                stonv = MultiplyMatrix(bp, stonv2);


                double[,] div = new double[2, 1];

                div = Multiplyt(stonj, stonv);



                cA = div.GetLength(0);
                min = 0;
                min2 = 1000;
                for (int i = 0; i < cA; i++)
                {
                    if (min2 > div[i, 0] && div[i, 0]>=0)
                    {
                        min = i;
                        min2 = div[i, 0];
                    }
                }
                int a2 = min;


                double lo = stonv[a2, 0];

                double[,] et = new double[pn, pn];

                rA = e1.GetLength(0);
                cA = e1.GetLength(1);
                for (int i = 0; i < rA; i++)
                    for (int j = 0; j < cA; j++)
                        et[i, j] = e1[i, j];

                et[a2, a2] = 1 / stonv[a2, 0];

                //pn chanch
                for (int k = 0; k < pn; k++)
                {
                    if (k != a2)
                        et[k, a2] = -1 * (stonv[k, 0] / lo);

                }

                bp = MultiplyMatrix(et, bp);

                //          if (k2 == 1)
                //            cs = 0;

                string xv = xn[0, a1];
                string xe = xb[a2, 0];

                xn[0, a1] = xe;

                xb[a2, 0] = xv;

                double zv = cn[0, a1];
                double ze = cb[0, a2];

                cn[0, a1] = ze;
                cb[0, a2] = zv;


                double[,] mn = new double[pn, 1];
                double[,] mb = new double[pn, 1];

                //pn chanch
                for (int k = 0; k < pn; k++)
                    mn[k, 0] = n[k, a1];

                for (int k = 0; k < pn; k++)
                    mb[k, 0] = b1[k, a2];

                for (int k = 0; k < pn; k++)
                    n[k, a1] = mb[k, 0];

                for (int k = 0; k < pn; k++)
                    b1[k, a2] = mn[k, 0];
            }



            double[,] cb2 = new double[2, 1];
            cb2 = MultiplyMatrix(bp, b);

            double[,] z = new double[1, 1];

            z = MultiplyMatrix(cb, cb2);
            if (kind.CompareTo(comboBox.Text) == 0)
            {
                z[0, 0] = z[0, 0] * -1;
            }



                label.Visibility = Visibility.Visible;

            if (dor == 100)
            {
                label.Content ="جواب پیدا نشد";
            }
            else
            {
                label.Content = z[0, 0].ToString();
            }
            
          
        }


        public double[,] MultiplyMatrix(double[,] A, double[,] B)
        {
            int rA = A.GetLength(0);
            int cA = A.GetLength(1);
            int rB = B.GetLength(0);
            int cB = B.GetLength(1);
            double temp = 0;
            double[,] kHasil = new double[rA, cB];
            if (cA != rB)
            {
               // Console.WriteLine("matrik can't be multiplied !!");
            }
            else
            {
                for (int i = 0; i < rA; i++)
                {
                    for (int j = 0; j < cB; j++)
                    {
                        temp = 0;
                        for (int k = 0; k < cA; k++)
                        {
                            temp += A[i, k] * B[k, j];
                        }
                        kHasil[i, j] = temp;
                    }
                }
                return kHasil;
            }

            return kHasil;
        }


        public double[,] Multiplydif(double[,] A, double[,] B)
        {

            int rA = A.GetLength(0);
            int cA = A.GetLength(1);
            double[,] javab = new double[rA, cA];
            for (int i = 0; i < rA; i++)
                for (int j = 0; j < cA; j++)
                    javab[i, j] = A[i, j] - B[i, j];

            return javab;

        }

        public double[,] Multiplyt(double[,] A, double[,] B)
        {

            int rA = A.GetLength(0);
            int cA = A.GetLength(1);
            double[,] javab = new double[rA, cA];
            for (int i = 0; i < rA; i++)
                for (int j = 0; j < cA; j++)
                    javab[i, j] = A[i, j] / B[i, j];

            return javab;

        }

       


        private void rb_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            string aaa = textBox.Text.ToString();
            listBox.Items.Add (aaa);
            textBox.Text = "";
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void textBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                string aaa = textBox.Text.ToString();
                listBox.Items.Add(aaa);
                textBox.Text = "";
            }
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            listBox.Items.Clear();
            label.Visibility = Visibility.Hidden;
        }
    }
}
